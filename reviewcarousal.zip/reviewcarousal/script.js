let currentIndex = 0;
const cards = document.querySelectorAll(".card");
const totalCards = cards.length;
let goLeft = document.querySelector("#leftArrow");
let goRight = document.querySelector("#rightArrow");
let surpriseButton = document.querySelector("#surprise-me");

function showCard(index) {
  cards.forEach((card, i) => {
    card.style.display = i === index ? "block" : "none";
  });
}

function nextCard() {
  currentIndex = (currentIndex + 1) % totalCards;
  showCard(currentIndex);
}

function prevCard() {
  currentIndex = (currentIndex - 1 + totalCards) % totalCards;
  showCard(currentIndex);
}

function surpriseMe() {
    console.log('hi');
  // Generate a random index to select a card
  const randomIndex = Math.floor(Math.random() * cards.length);

  // Hide all cards
  cards.forEach((card) => {
    card.style.display = "none";
  });

  // Show the randomly selected card
  cards[randomIndex].style.display = "block";
}

surpriseButton.addEventListener("click", surpriseMe);

showCard(currentIndex);
